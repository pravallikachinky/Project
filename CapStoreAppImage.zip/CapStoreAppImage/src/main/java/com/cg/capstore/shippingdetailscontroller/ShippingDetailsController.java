package com.cg.capstore.shippingdetailscontroller;

import java.awt.image.DataBufferByte;
import java.lang.instrument.ClassDefinition;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;

import org.aspectj.apache.bcel.classfile.ClassParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.beans.CustomerBean;
import com.cg.capstore.beans.ImageBean;
import com.cg.capstore.beans.OrderBean;
import com.cg.capstore.beans.ProductBean;
import com.cg.capstore.shippingdetailsservice.IShippingDetailsService;

@RestController
public class ShippingDetailsController {

	@Autowired
	private IShippingDetailsService service;
	
	@Autowired
	private JavaMailSender sender;

	 @RequestMapping("/simpleemail")
	    public String home(String email) {
		 
		 System.err.println("given:"+email);
	         try {
	        	 System.err.println(service.shippingDetailsMsg(email));
	            String customerEmail=service.shippingDetailsMsg(email).getEmail();
	          //  sendEmail(customerEmail);
	             return "Email Sent! to "+customerEmail;
	         }catch(Exception ex) {
	             return "Error in sending email: "+ex;
	         }
	     }

	     private void sendEmail(String customerEmail) throws Exception{
	         MimeMessage message = sender.createMimeMessage();
	         MimeMessageHelper helper = new MimeMessageHelper(message);
	         CustomerBean customer=service.shippingDetailsMsg(customerEmail);
	         OrderBean order=customer.getOrder();
	         ProductBean product=new ProductBean(order.getProduct());
	         ImageBean image=(ImageBean) product.getImageId();
	       //  DataSource dataImage=image.getImage();
	         helper.setTo(customerEmail);
	         helper.setText("Hello " +customer.getCustomerName() +",\n Your delivery date is on" +order.getDeliveryDate()
	         +"\n Your order will be send to the address:\n" +customer.getAddress() );
	         helper.setSubject("Hi");
	         helper.setText(image.getImage());
	         helper.setText(product.getPrice().toString());
	         
	       //  helper.setText("hello", "localhost:7878/simpleemail?email=chinkygilla96@gmail.com");
	       //  ClassDefinition pic=new ClassDefinition(ImageBean.class, image.getImage());
	      //   DataBufferByte data=new DataBufferByte(arg0, arg1)
	       //  helper.setText(i);
	         sender.send(message);
	     }

}

package com.cg.capstore.shippingdetailsservice;

import com.cg.capstore.beans.CustomerBean;
import com.cg.capstore.beans.ProductBean;

public interface IShippingDetailsService {

	public CustomerBean shippingDetailsMsg(String email);
	
}
